<?php
//header('Content-type: text/html; charset=utf-8');
$bot = new Bot();
$bot->init('php://input');
class Bot {
    private $botToken = "5684948299:AAHa3NhGYHfxVcXemExopbJYPDEOG-3ytuw";
    private $apiUrl = "https://api.telegram.org/bot";

    public function init($data): void
    {
        date_default_timezone_set('Asia/Tashkent');
        $arrData = $this->getData($data);
        $message = ''; $chat_id = 0; $message_id = 0; $chat_name = '';
        if (array_key_exists('message', $arrData)) {
            $chat_id = $arrData['message']['chat']['id'];
            $message = $arrData['message']['text'];
        } elseif (array_key_exists('callback_query', $arrData)) {
            $chat_id = $arrData['callback_query']['message']['chat']['id'];
            $message_id = $arrData['callback_query']['message']['message_id'];
            $chat_name = $arrData['callback_query']['from']['first_name'] . ' ' . $arrData['callback_query']['from']['last_name'];
            $message = $arrData['callback_query']['data'];
        }
        require 'connect.php';
        switch ($message) {
            case '/start':
                $check_telegram = mysqli_query($connect, "SELECT `name` FROM `teachers` WHERE `telegram_id` = '$chat_id'");
                if (!count(mysqli_fetch_array($check_telegram))) {
                    $text_hello = "<b>Assalawma áleykum. Iltimas tómendegi dizimnen ózińizdiń atı familiyańızdı belgileń!</b>";
                    $no_user = mysqli_query($connect, "SELECT `name`,`employee_id` FROM `teachers` WHERE `active` = '0' ORDER BY (`name`)");
                    $data_inline = [];
                    while ($res = mysqli_fetch_array($no_user)) {
                        $data_inline[] = [['text' => $res['name'], 'callback_data' => 'emp_' . $res['employee_id']]];
                    }
                    $dataSendAdmin = array(
                        'text' => $text_hello,
                        'chat_id' => $chat_id,
                        'reply_markup' => $this->getInlineKeyBoard($data_inline),
                        'parse_mode' => "HTML"
                    );
                    $this->requestToTelegram($dataSendAdmin, 'sendMessage');
                }

                /*$dataSendText = array(
                    'text' => 'HH',
                    'chat_id' => 310857127,
                    'parse_mode' => 'HTML',
                );
                $this->requestToTelegram($dataSendText, 'sendMessage');*/

                break;

            case (strpos($message, 'emp_') === 0):
                $exp = explode('_', $message);
                $where = intval($exp[1]);

                $text_hello = "<b>Raxmet! Men Sizdi sabaq ótiletuǵın waqıtta xabarlandırıp hám Zoom platformasına jalǵanıw ushın link taslap turaman!</b>";

                mysqli_query($connect, "UPDATE `teachers` SET `telegram_id` = '$chat_id', `active` = '1' WHERE `employee_id` = '$where'");
                $dataSend = array(
                    'text' => $text_hello,
                    'chat_id' => $chat_id,
                    'message_id' => $message_id,
                    'parse_mode' => "HTML"
                );
                $this->requestToTelegram($dataSend, 'editMessageText');
                if (strpos($message, 'emp_')) {
                    $user = mysqli_fetch_array(mysqli_query($connect, "SELECT * FROM `teachers` WHERE `employee_id` = '$where'"));
                    $dataSendAdmin = array(
                        'text' => "[" . $user['name'] . "](tg://user?id=$chat_id) ({$chat_name}) botta dizimnen ótti hám Telegram: {$chat_id} id nomeri boyınsha HEMIS: {$where} id nomerine biriktirildi!",
                        'chat_id' => 310857127,
                        'parse_mode' => "markdown"
                    );
                    $this->requestToTelegram($dataSendAdmin, 'sendMessage');
                }
                break;
            default:

                break;
        }
    }

    private function getKeyBoard($data): bool|string
    {
        $keyboard = array(
            "keyboard" => $data,
            "one_time_keyboard" => false,
            "resize_keyboard" => true
        );
        return json_encode($keyboard);
    }

    private function deleteMessage($messageid, $chat_id): void
    {
        $dataSend = array(
            'message_id' => $messageid,
            'chat_id' => $chat_id,
        );
        $this->requestToTelegram($dataSend, "deleteMessage");
    }

    private function getInlineKeyBoard($data): bool|string
    {
        $inlineKeyboard = array(
            "inline_keyboard" => $data,
        );
        return json_encode($inlineKeyboard);
    }

    private function getData($data)
    {
        return json_decode(file_get_contents($data), TRUE);
    }

    private function requestToTelegram($data, $type): void
    {
        $result = null;

        if (is_array($data)) {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $this->apiUrl . $this->botToken . '/' . $type);
            curl_setopt($ch, CURLOPT_POST, count($data));
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
            $result = curl_exec($ch);
            curl_close($ch);
        }
    }
}
