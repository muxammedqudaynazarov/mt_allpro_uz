<?php
header('content-type: application/json');
require_once 'connect.php';
$date = $_GET['date'];
$begin = $_GET['begin'];
$get = mysqli_query($connect, "SELECT * FROM `meets` WHERE `date` = '$date' AND `begin` = '$begin' GROUP BY `employee_id`");
while ($res = mysqli_fetch_array($get)) {
    $group_id = $res['group_id'];
    $employee_id = $res['employee_id'];
    $group = mysqli_fetch_array(mysqli_query($connect, "SELECT * FROM `groups` WHERE `hemis_id` = '$group_id'"));
    $employee = mysqli_fetch_array(mysqli_query($connect, "SELECT * FROM `teachers` WHERE `employee_id` = '$employee_id'"));
    $total_get = mysqli_query($connect, "SELECT * FROM `meets` WHERE `employee_id` = '$employee_id' AND `date` = '$date' AND `begin` = '$begin'");
    $text = "Assalawma áleykum, " . $employee['name'] . '.';
    $text .= " Siziń, <b>";
    if (mysqli_num_rows($total_get) > 1) {
        $count = 1;
        while ($gr = mysqli_fetch_array($total_get)) {
            $group_id_x = $gr['group_id'];
            $group_x = mysqli_fetch_array(mysqli_query($connect, "SELECT * FROM `groups` WHERE `hemis_id` = '$group_id_x'"));
            $text .= $group_x['name'];
            if ($count < mysqli_num_rows($total_get)) $text .= ', ';
            $count++;
        }
        $text .= ' toparlarındaǵı, ';
    } else {
        $text .= $group['name'] . " toparındaǵı, ";
    }
    $text .= $res['lesson_name'] . ' (' . $res['type'] . ")</b> sabaǵıńızǵa ZOOM link jaratıldı. Tómendegi «Sabaqtı baslaw» túymesin basıp sabaq ótiwdi baslasańız boladı.\n\n«Studentlerge link jiberiw» túymesin basıp kerekli gruppaǵa jiberiwdi umıtpań!\n\n‼️ Eskertiw: Sabaq saat ";
    $text .= $res['end'] . " avtomatikalıq juwmaqlanadı!\n\n<b>Studentler ushın:</b>\n";
    $text .= '<code>' . $res['join_url'] . '</code>';
    $data_teacher = http_build_query([
        'text' => $text,
        'chat_id' => $employee['telegram_id'],
        'parse_mode' => 'html'
    ]);
    $keyboard_teacher = json_encode([
        "inline_keyboard" => [[
            [
                "text" => "Sabaqtı baslaw",
                "url" => $res['start_url'],
            ],
            [
                'text' => 'Studentlerge link jiberiw',
                'url' => 'https://t.me/share/url?url=' . $res['join_url'],
            ]]]]);

    $url = "https://api.telegram.org/bot5684948299:AAHa3NhGYHfxVcXemExopbJYPDEOG-3ytuw/sendMessage?{$data_teacher}&reply_markup={$keyboard_teacher}";
    $send_data = json_decode(file_get_contents($url));
    $upd_id = $res['id'];
    $message_id = $send_data->result->message_id;
    mysqli_query($connect, "UPDATE `meets` SET `message_id` = '$message_id' WHERE `id` = '$upd_id'");

    $admins = [310857127, 149523019, 479901682];

    foreach ($admins as $admin) {
        $data_admin = http_build_query([ 'text' => $text, 'chat_id' => $admin, 'parse_mode' => 'html' ]);

        $url_admin = "https://api.telegram.org/bot5684948299:AAHa3NhGYHfxVcXemExopbJYPDEOG-3ytuw/sendMessage?{$data_admin}&reply_markup={$keyboard_teacher}";
        $send_admin = json_decode(file_get_contents($url_admin));
    }

}
