<?php
require_once 'connect.php';
header('Content-type: application/json');

$groups = mysqli_query($connect, "SELECT * FROM `groups` WHERE `active` = '1'");
mysqli_query($connect, "TRUNCATE ` meets `");
$begin_week = strtotime('Monday this week');
$end_week = strtotime('Sunday this week');

while ($row = mysqli_fetch_array($groups)) {
    echo $row['name'] . "\n";
    $ch = curl_init();
    $group_id = intval($row['hemis_id']);
    $headers = array(
        'accept: application/json',
        'Authorization: Bearer U0on7Mpb5S36imt0dKFFI6OlZS78xlM3',
    );
    curl_setopt($ch, CURLOPT_URL, "https://student.karsu.uz/rest/v1/data/schedule-list?_group=$group_id&_semester=12&lesson_date_from=$begin_week&lesson_date_to=$end_week");
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $faculties = curl_exec($ch);
    $data = json_decode($faculties);

    foreach ($data->data->items as $val) {
        $lesson_name = str_replace('\'', '‘', $val->subject->name);
        $lesson_id = $val->id;
        $group_id = $val->group->id;
        $begin = $val->lessonPair->start_time;
        $end = $val->lessonPair->end_time;
        $employee_id = $val->employee->id;
        $date = date('d.m.Y', $val->lesson_date);
        $type = str_replace('\'', '‘', $val->trainingType->name);
        $check = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `meets` WHERE `lesson_id` = '$lesson_id'"));
        if (!$check)
            mysqli_query($connect, "INSERT INTO `meets` (`lesson_id`, `lesson_name`, `employee_id`, `group_id`, `type`, `begin`, `end`, `date`) VALUES ('$lesson_id', '$lesson_name', '$employee_id', '$group_id', '$type', '$begin', '$end', '$date')");
    }
}

