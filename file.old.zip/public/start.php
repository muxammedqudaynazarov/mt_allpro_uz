<?php
header("content-type: application/json");
require_once 'Zoom/Index.php';
date_default_timezone_set('Asia/Tashkent');
use Zoom\Meeting;
$meeting = new Meeting();
$meeting->email = $_GET['email'];
$data = [
    'topic' => $_GET['topic'],
    'type' => 1,
    'start_time' => (isset($_GET['time'])) ? date("Y-m-d\TH:i:s\Z", $_GET['time']) : date("Y-m-d\TH:i:s\Z"),
    'duration' => 80,
    'timezone' => 'UTC+5',
    'agenda' => '',
    'password' => '2023',
    'settings' => [
        'host_video' => false,
        'participant_video' => true,
        'in_meeting' => false,
        'join_before_host' => false,
        'mute_upon_entry' => false,
        'use_pmi' => false,
        'approval_type' => 1,
        'audio' => 'both',
        'auto_recording' => 'none',
        'enforce_login' => false,
        'registrants_email_notification' => false,
        'email_notification' => false,
    ],
];
$meeting = $meeting->create($data);
echo json_encode($meeting);
