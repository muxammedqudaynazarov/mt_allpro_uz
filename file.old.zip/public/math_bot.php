<?php
header('Content-type: text/html; charset=utf-8');
$bot = new Bot();
$bot->init('php://input');

//echo shell_exec("python3 file.py < /var/www/mt.allpro.uz/public/input.txt");
class Bot {
    private $botToken = "6132519271:AAH6B3plje17V_e2xQ6I9NeQ0emqRP5CCH8";
    private $apiUrl = "https://api.telegram.org/bot";
    public function init($data) {
        date_default_timezone_set('Asia/Tashkent');
        $arrData = $this->getData($data);
        $chat_id = 0; $message = 0;
        if (array_key_exists('message', $arrData)) {
            $chat_id = $arrData['message']['chat']['id'];
            $message = $arrData['message']['text'];
        } elseif (array_key_exists('callback_query', $arrData)) {
            $chat_id = $arrData['callback_query']['message']['chat']['id'];
            $message = $arrData['callback_query']['data'];
        }
        $connect = mysqli_connect('localhost', 'math_word', 'CgaDqkEw[FL_hHmN', 'math_word');
        $get = mysqli_query($connect, "SELECT * FROM `users` WHERE `telegram_id` = '$chat_id'");
        if (mysqli_num_rows($get)) {
            $user = mysqli_fetch_array($get);
            switch ($message) {
                case '/start':
                    $text_hello = "<b>Assalawma áleykum, " . $user['name'] . "</b>";
                    $dataSendAdmin = array(
                        'text' => $text_hello,
                        'chat_id' => $chat_id,
                        'parse_mode' => "HTML"
                    );
                    $this->requestToTelegram($dataSendAdmin, 'sendMessage');
                    break;

                case '/info':
                    $all = mysqli_query($connect, "SELECT * FROM `users` WHERE `role` = 'a' ORDER BY(`pos`)");
                    $tw = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `words`"));
                    $text = "📝 <b>Ulıwma sózlerdiń sanı: $tw </b>\n\n<i>Sonnan:\n\n";
                    while ($r = mysqli_fetch_array($all)) {
                        $user_id = $r['telegram_id'];
                        $uw = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `words` WHERE `telegram_id` = '$user_id'"));
                        $text .= $r['name'] . ': ' . $uw . "\n";
                    }
                    $text .= '</i>';
                    $dataSendAdmin = array(
                        'text' => $text,
                        'chat_id' => $chat_id,
                        'parse_mode' => "HTML"
                    );
                    $this->requestToTelegram($dataSendAdmin, 'sendMessage');
                    break;

                case '/export':
                    $w = mysqli_query($connect, "SELECT * FROM `words` ORDER BY(`original`)");
                    if (mysqli_num_rows($w)) {
                        shell_exec('remove.sh');
                        $new_text = "";
                        while ($tt = mysqli_fetch_array($w)) {
                            $new_text .= $tt['original'] . '$';
                        }
                        file_put_contents('values_base.txt', $new_text);
                        shell_exec("python3 download_start.py < /var/www/mt.allpro.uz/public/values_base.txt");
                        $ch = curl_init();
                        curl_setopt($ch, CURLOPT_URL, "https://api.telegram.org/bot" . $this->botToken . "/sendDocument?chat_id=" . $chat_id);
                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                        curl_setopt($ch, CURLOPT_POST, 1);
                        $finfo = finfo_file(finfo_open(FILEINFO_MIME_TYPE), 'last_edit_download.docx');
                        $cFile = new CURLFile('last_edit_download.docx', $finfo);
                        curl_setopt($ch, CURLOPT_POSTFIELDS, [
                            "document" => $cFile,
                            'caption' => "<b>Siz fayldı kóshirip aldıńız!\nWaqtı:</b> <code>" . date('d.m.Y H:i:s') . '</code>',
                            'parse_mode' => 'html'
                        ]);
                        curl_exec($ch);
                    } else {
                        $dataSendAdmin = array(
                            'text' => "<b>Házirgi waqıtta bazaǵa birde-bir sóz kiritilmegen!</b>",
                            'chat_id' => $chat_id,
                            'parse_mode' => "HTML"
                        );
                        $this->requestToTelegram($dataSendAdmin, 'sendMessage');
                    }
                    break;

                default:
                    $original = $message;
                    $message = strtolower($message);
                    $check_word = mysqli_query($connect, "SELECT * FROM `words` WHERE `word` = '$message'");
                    $now = date('Y-m-d H:i:s');
                    $text = "";
                    if (!mysqli_num_rows($check_word)) {
                        mysqli_query($connect, "INSERT INTO `words`(`telegram_id`,`word`,`original`,`created_at`,`updated_at`)
                        VALUES ('$chat_id', '$message', '$original', '$now', '$now')");
                        $text = "✅ <b>Siz jazǵan «</b><code>$original</code><b>» termini bazaǵa jazıp alındı. Raxmet!</b>";
                    } else {
                        $text = "❌ <b>Siz jazǵan «</b><code>$original</code><b>» termini aldınnan bazada bar. Basqa terminlerdi jazsańız boladı!</b>";
                    }
                    $text .= "\n\n<i>/info - maǵlıwmat alıw komandası\n/export - sózler dizimin docx fayl formasında kóshirip alıw</i>";
                    $dataSendAdmin = array(
                        'text' => $text,
                        'chat_id' => $chat_id,
                        'parse_mode' => "HTML"
                    );
                    $this->requestToTelegram($dataSendAdmin, 'sendMessage');
                    break;
            }
        }


    }

    private function getKeyBoard($data)
    {
        $keyboard = array(
            "keyboard" => $data,
            "one_time_keyboard" => false,
            "resize_keyboard" => true
        );
        return json_encode($keyboard);
    }

    private function deleteMessage($messageid, $chat_id) {
        $dataSend = array(
            'message_id' => $messageid,
            'chat_id' => $chat_id,
        );
        $this->requestToTelegram($dataSend, "deleteMessage");
    }

    private function getInlineKeyBoard($data)
    {
        $inlineKeyboard = array(
            "inline_keyboard" => $data,
        );
        return json_encode($inlineKeyboard);
    }

    private function getData($data)
    {
        return json_decode(file_get_contents($data), TRUE);
    }

    private function requestToTelegram($data, $type)
    {
        $result = null;

        if (is_array($data)) {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $this->apiUrl . $this->botToken . '/' . $type);
            curl_setopt($ch, CURLOPT_POST, count($data));
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
            $result = curl_exec($ch);
            curl_close($ch);
        }
        return $result;
    }
}
