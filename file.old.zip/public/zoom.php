<?php

// Replace with your API key
$api_key = '0JV73PAOS2W4t5kltyDgUA';

// Replace with your Zoom user ID
$user_id = 'Pt1_PgtCTWOuHJHy_h2i_g';

// Meeting details
$topic = 'My Meeting';
$type = 2;
$start_time = '2022-01-01T09:00:00Z';
$duration = 60;
$timezone = 'UTC';

// Create a new meeting
$data = json_encode([
    'topic' => $topic,
    'type' => $type,
    'start_time' => $start_time,
    'duration' => $duration,
    'timezone' => $timezone
]);

// Prepare the request
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.zoom.us/v2/users/' . $user_id . '/meetings');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: Bearer ' . $api_key
]);

// Send the request
$response = curl_exec($ch);
$status_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

// Handle the response
if ($status_code == 201) {
    $meeting = json_decode($response);
    echo 'Meeting created: ' . $meeting->join_url;
} else {
    echo 'Error: ' . $response;
}

