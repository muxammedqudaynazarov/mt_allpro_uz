<?php
$connect = mysqli_connect('localhost', 'mt_timetable', 'B[WuA)F[rhMuHWDt', 'mt_timetable');
date_default_timezone_set('Asia/Tashkent');
