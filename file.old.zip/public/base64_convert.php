<?php
header('Content-Type: application/json');
$fn = uniqid() . '.png';
$put = './math/' . $fn;
$data = $_GET['data'];
$img = str_replace('data:image/png;base64,', '', $data);
$img = str_replace(' ', '+', $img);
file_put_contents($put, base64_decode($img));
$arr = [];
if (file_exists($put)) {
    $arr = [
        'result' => true,
        'filename' => $fn,
        'url' => 'https://mt.allpro.uz/math/' . $fn,
    ];
} else {
    $arr['result'] = false;
}
echo json_encode($arr);