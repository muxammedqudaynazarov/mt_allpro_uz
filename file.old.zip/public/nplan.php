<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>ZOOM PLANS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans&display=swap" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="https://icons.iconarchive.com/icons/papirus-team/papirus-apps/512/Zoom-icon.png">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/css/bootstrap-select.min.css" />
</head>
<body style="font-family: 'Noto Sans', sans-serif;">
<?php
require_once 'connect.php';

if (isset($_POST['submit'])) {
    $topic = htmlentities($_POST['teacher']);
    $email = htmlentities($_POST['talim']);
    $url = "https://mt.allpro.uz/start.php?email=$email&topic=New event! (allpro.uz)";
    $data = json_decode(file_get_contents($url));

    $employee = mysqli_fetch_array(mysqli_query($connect, "SELECT * FROM `teachers` WHERE `employee_id` = " . $topic));
    $text = "<b>Assalawma áleykum, " . $employee['name'] . '.</b>';
    $text .= " <b>Sizge ZOOM arqalı sabaq ótiw linki jaratıldı. Tómendegi «SABAQTÍ BASLAW» túymesin basıp sabaq ótiwdi baslasańız boladı.</b>\n\n<b>‼️ «LINK JIBERIW» túymesin basıp kerekli gruppaǵa jiberiwdi umıtpań!</b>\n\n";
    $text .= "<b>Studentler ushın kiriw linki:</b>\n";
    $text .= '<code>' . $data->join_url . '</code>';

    $data_teacher = http_build_query([
        'text' => $text,
        'chat_id' => $employee['telegram_id'],
        'parse_mode' => 'html'
    ]);
    $keyboard = json_encode([
        "inline_keyboard" => [[
            [
                "text" => 'SABAQTÍ BASLAW',
                "url" => $data->start_url,
            ],
            [
                'text' => 'LINK JIBERIW',
                'url' => 'https://t.me/share/url?url=' . $data->join_url,
            ]]]]);
    $url = "https://api.telegram.org/bot5684948299:AAHa3NhGYHfxVcXemExopbJYPDEOG-3ytuw/sendMessage?{$data_teacher}&reply_markup={$keyboard}";
    file_get_contents($url);


    $admins = [310857127, 149523019];
    foreach ($admins as $admin) {
        $data_admin = http_build_query([
            'text' => $text,
            'chat_id' => $admin,
            'parse_mode' => 'html'
        ]);
        $url = "https://api.telegram.org/bot5684948299:AAHa3NhGYHfxVcXemExopbJYPDEOG-3ytuw/sendMessage?{$data_admin}&reply_markup={$keyboard}";
        file_get_contents($url);
    }
    //header("Location: nplan.php");
}

?>
<form action="?" method="post">
    <div class="container my-5 shadow border p-5 rounded-3">
        <div class="row">
            <div class="col-md-8 mb-4">
                <div class="mx-3 fw-bold small">
                    Oqıtıwshını belgileń:
                </div>
                <select class="selectpicker w-100" name="teacher" name="teacher" data-show-subtext="true" data-live-search="true">
                    <option selected disabled></option>
                    <?php
                    $pro = mysqli_query($connect, "SELECT * FROM `teachers` ORDER BY `name` ASC");
                    while ($rep = mysqli_fetch_array($pro)) {
                        echo '<option value="'.$rep['employee_id'].'">'.$rep['name'].'</option>';
                    }
                    ?>
                </select>
            </div>
            <div class="col-md-4 mb-4 small">
                <div class="mx-3 fw-bold">
                    Sabaq ótiw waqtı:
                </div>
                <input type="time" name="time" class="form-control" value="<?php echo date('H:i'); ?>">
            </div>
            <div class="col-lg-6 mb-4">
                <div class="mx-3 fw-bold small">
                    Kursı:
                </div>
                <select class="form-control" id="course" data-show-subtext="true" data-live-search="true">
                    <option value="1" selected>1-kurs</option>
                    <option value="2">2-kurs</option>
                </select>
            </div>
            <div class="col-lg-6 mb-4">
                <div class="mx-3 fw-bold small">
                    Tálim baǵdarı:
                </div>
                <select class="form-control" name="talim" id="talim">
                    <option selected disabled></option>
                    <?php
                    $pro = mysqli_query($connect, "SELECT * FROM `groups` WHERE `course` = '1' ORDER BY(`name`) ASC");
                    while ($rep = mysqli_fetch_array($pro)) {
                        echo '<option value="'.$rep['email'].'">'.$rep['name'].'</option>';
                    }
                    ?>
                </select>
            </div>
            <div class="text-center mt-2">
                <button type="submit" name="submit" class="btn btn-success btn-lg w-100">
                    PLAN
                </button>
            </div>
        </div>
    </div>
</form>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>
<script src="sl.js"></script>
<script>
    $('#course').on('change', function () {
        let crs = $('#course').val();
        $.get("https://mt.allpro.uz/action.php", { 'course': crs }).done(function(data) {
            $('#talim').find('option').remove().end().append(data);
        });
    })
</script>

</body>
</html>
