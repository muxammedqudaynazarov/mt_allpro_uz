<?php
namespace Zoom;
class Config {
    public static $api_key = '0JV73PAOS2W4t5kltyDgUA';
    public static $secret_key = 'txLnEJfacjsmWYiR2MlQOQJRP59WgmwxjokH';
    public static $email = 'kgu.zoom3@works.uz';
}
