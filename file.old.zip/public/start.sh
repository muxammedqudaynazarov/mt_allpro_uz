php -q /var/www/mt.allpro.uz/public/plans.php
