<?php
header('Content-type: application/json');
require_once 'connect.php';
$date = date('d.m.Y');
function start($date, $clock) {
    global $connect;
    $get = mysqli_query($connect, "SELECT * FROM `meets` WHERE `date` = '$date' AND `begin` = '$clock'");
    while ($res = mysqli_fetch_array($get)) {
        $topic = $res['lesson_name'];
        $group_id = $res['group_id'];
        $employee_id = $res['employee_id'];
        $group = mysqli_fetch_array(mysqli_query($connect, "SELECT * FROM `groups` WHERE `hemis_id` = '$group_id'"));
        $employee = mysqli_fetch_array(mysqli_query($connect, "SELECT * FROM `teachers` WHERE `employee_id` = '$employee_id'"));
        $email = $group['email'];
        $time = strtotime($res['begin'] . ':00 ' . $res['date']);
        $data = file_get_contents("https://mt.allpro.uz/start.php?topic=$topic&email=$email&time=$time");
        $data = json_decode($data);
        $id = $res['id'];
        mysqli_query($connect, "UPDATE `meets` SET `start_url` = '$data->start_url', `join_url` = '$data->join_url', `meet_id` = '$data->id' WHERE `id` = '$id'");
    }
}
function finish($date, $clock) {
    file_get_contents("https://mt.allpro.uz/finish.php?date=$date&end=$clock");
}
if (date('H:i') == "14:25") {
    start($date, "14:30");
    file_get_contents("https://mt.allpro.uz/send.php?date=$date&begin=14:30");
} elseif (date('H:i') == "15:50") {
    finish($date, "15:50");
} elseif (date('H:i') == "15:55") {
    start($date, "16:00");
    file_get_contents("https://mt.allpro.uz/send.php?date=$date&begin=16:00");
} elseif (date('H:i') == "17:20") {
    finish($date, "17:20");
} elseif (date('H:i') == "17:25") {
    start($date, "17:30");
    file_get_contents("https://mt.allpro.uz/send.php?date=$date&begin=17:30");
} elseif (date('H:i') == "18:50") {
    finish($date, "18:50");
}

