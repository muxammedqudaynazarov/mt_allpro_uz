from docx import Document

document = Document()
text_in = input()
text_in = text_in.split('$')
for i in text_in:
    document.add_paragraph(i)

document.save('last_edit_download.docx')