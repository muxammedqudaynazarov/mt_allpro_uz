<?php
require_once 'connect.php';
date_default_timezone_set('Asia/Tashkent');
$mac = $_GET['mac'];
$botAPI = '6689594617:AAGy1ZMCWFtvxtKFxb2SeLi-RUYFCaFsYRY';

$access_all = 1;
$inTable = mysqli_query($connect, "SELECT * FROM `check_user` WHERE `mac` = '$mac'");
if (!mysqli_num_rows($inTable)) {
    mysqli_query($connect, "INSERT INTO `check_user`(`mac`, `who_reg`, `active`) VALUES ('$mac', 0, '$access_all')");

    if (!$access_all) {
        $admins = [310857127, 1109853226];
        $keyboard = json_encode([
            "inline_keyboard" => [
                [
                    [
                        "text" => "РУХСАТ БЕРИШ",
                        "callback_data" => "accept"
                    ]
                ]
            ]
        ]);
        foreach ($admins as $admin) {
            $data = http_build_query([
                'text' => "<b>УШБУ,</b> <code>$mac</code> <b>MAC-АДРЕС СИЗДАН ДАСТУРДАН ФОЙДАЛАНИШГА РУХСАТ СЎРАЙДИ?</b>",
                'chat_id' => $admin,
                'parse_mode' => 'HTML'
            ]);
            $url = "https://api.telegram.org/bot$botAPI/sendMessage?$data&reply_markup=$keyboard";
            file_get_contents($url);
        }
    }
}
$vTable = mysqli_fetch_array(mysqli_query($connect, "SELECT `active` FROM `check_user` WHERE `mac` = '$mac'"));
$date = date('Y-m-d H:i:s');
mysqli_query($connect, "UPDATE `check_user` SET `created_at` = '$date' WHERE `mac` = '$mac'");
if($vTable['active'] == '0') echo 'emas';
else echo 'mumkun';

