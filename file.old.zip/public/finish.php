<?php
header("content-type: text/plain");
require_once 'Zoom/Index.php';
use Zoom\Meeting;
require_once 'connect.php';
$meeting = new Meeting();

$date = $_GET['date'];
$end = $_GET['end'];
$get = mysqli_query($connect, "SELECt * FROM `meets` WHERE `date` = '$date' AND `end` = '$end'");
while ($res = mysqli_fetch_array($get)) {
    $id = $res['id'];
    $meeting = $meeting->end(intval($res['meet_id']));
}
