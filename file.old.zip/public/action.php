<?php
require_once 'connect.php';
$course = intval($_GET['course']);
$pro = mysqli_query($connect, "SELECT * FROM `groups` WHERE `course` = '$course' ORDER BY(`name`) ASC");
echo '<option selected disabled></option>';
while ($rep = mysqli_fetch_array($pro)) {
    echo '<option value="'.$rep['email'].'">'.$rep['name'].'</option>';
}