<?php

$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, 'http://185.8.212.184/smsgateway/');
curl_setopt($curl, CURLOPT_HEADER, 0);
curl_setopt($curl, CURLOPT_POST, 1);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 5);
curl_setopt($curl, CURLOPT_TIMEOUT, 5);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
$phone = $_GET['phone'];
$text = $_GET['text'];
$data = [
    'login' => 'muxamed',
    'password' => 'qdW066393obAvk5vN4P3',
    'data' => json_encode([
        [
            'phone' => $phone,
            'text' => "$text",
        ],
    ])
];
curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
$res = curl_exec($curl);
echo $res; curl_close($curl);
