<?php
$client_id = 'Dv8QWeWSTLidRi78BNYOxQ';
$client_secret = 'vr0fHOjnS5WEvk1ciZcIXFnP9a5D4h5f';
$token_url = 'https://authorization-server.com/token';
$params = [
    'grant_type' => 'client_credentials',
    'client_id' => $client_id,
    'client_secret' => $client_secret,
];
$ch = curl_init($token_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
$response = curl_exec($ch);
if (curl_errno($ch)) {
    echo 'cURL error: ' . curl_error($ch);
} else {
    $http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    if ($http_status == 200) {
        $token_data = json_decode($response, true);
        $access_token = $token_data['access_token'];
        echo 'Access token obtained: ' . $access_token;
    } else {
        echo 'Error obtaining access token. HTTP Status Code: ' . $http_status;
        echo $response;
    }
}
curl_close($ch);