<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <?php if($teachers): ?>
                <div class="col-md-8">
                    <div class="card mb-3">
                        <div class="card-body">
                            <form action="?" method="get">
                                <div class="row">
                                    <div class="col-md-9 mb-3 mb-lg-0">
                                        <div class="form-floating">
                                            <select class="form-select" id="teacher_id" name="teacher_id">
                                                <option selected disabled></option>
                                                <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($teacher->hemis_id); ?>">
                                                        <?php echo e($teacher->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <label for="teacher_id">Профессор-ўқитувчини танланг</label>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <button type="submit" class="btn btn-success py-2 mt-lg-2 w-100">
                                            Филтрлаш
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header fw-bold">
                        <div class="d-flex">
                            <div class="flex-grow-1 py-1">Админ панель</div>
                            <div class="mx-1">
                                <a href="<?php echo e(url('/home/meets')); ?>" class="btn btn-success btn-sm">
                                    Дарс яратиш
                                </a>
                            </div>
                            <?php if(auth()->user()->role == 'admin'): ?>
                                <div class="mx-1">
                                    <a href="<?php echo e(url('/generate_token')); ?>" class="btn btn-success btn-sm">
                                        Токен янгилаш
                                    </a>
                                </div>
                            <?php endif; ?>
                            <?php if(auth()->user()->role == 'admin'): ?>
                                <div class="mx-1">
                                    <a href="<?php echo e(url('/home/teacher_insert')); ?>" class="btn btn-success btn-sm">
                                        Ўқитувчи қўшиш
                                    </a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php $__currentLoopData = $meets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card mb-2">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-9">
                                            <div class="fw-bold">
                                                Мавзу: <?php echo e($meet->topic); ?>

                                            </div>
                                            <div class="small">
                                                <div>
                                                    Гуруҳ: <?php echo e(\App\Models\Application::group_name($meet->_to)); ?>

                                                </div>
                                                <div>
                                                    Бошлаш вақти: <?php echo e(date('d.m.Y H:i', strtotime($meet->created_at))); ?>

                                                </div>
                                                <div>
                                                    Якунлаш вақти: <?php echo e(date('d.m.Y H:i', strtotime($meet->ended_at))); ?>

                                                </div>
                                                
                                            </div>
                                        </div>
                                        <div class="col-3 text-center h-100 align-middle">
                                            <?php if(strtotime($meet->ended_at) > time()): ?>
                                                <?php if($meet->status == 'w'): ?>
                                                    <div>
                                                        <a href="<?php echo e($meet->start_url); ?>" target="_blank"
                                                           class="btn btn-outline-success btn-sm mb-1">
                                                            Дарсни бошлаш
                                                        </a>
                                                    </div>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            <?php if(auth()->user()->role == 'admin' && $meet->status == 'w'): ?>
                                                <div>
                                                    <a href="<?php echo e(url('/home/delete/' . $meet->meet_id)); ?>"
                                                       class="btn btn-outline-dark btn-sm mb-1">
                                                        Дарсни якунлаш
                                                    </a>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php echo e($meets->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $('.pagination').addClass('justify-content-center');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\zoom.lc\resources\views/home.blade.php ENDPATH**/ ?>