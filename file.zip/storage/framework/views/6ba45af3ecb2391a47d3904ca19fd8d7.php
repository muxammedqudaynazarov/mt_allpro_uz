<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header fw-bold">
                        <div class="d-flex">
                            <div class="flex-grow-1 py-1">Дарс яратиш</div>
                            <div>
                                <a href="<?php echo e(url('/home')); ?>" class="btn btn-success btn-sm">
                                    Бекор қилиш
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <form action="?" method="post">
                            <?php if($teachers): ?>
                                <div class="form-floating mb-3">
                                    <select class="form-select" id="teacher"
                                            name="teacher" aria-label="Профессор-ўқитувчини танланг">
                                        <option selected disabled></option>
                                        <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($teacher->hemis_id); ?>">
                                                <?php echo e($teacher->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <label for="teacher">Профессор-ўқитувчини танланг</label>
                                </div>
                            <?php endif; ?>

                            <div class="btn-group w-100 mb-3" role="group">
                                <input type="radio" class="btn-check" name="course" value="1" id="course_1"
                                       checked>
                                <label class="btn btn-outline-primary" for="course_1">1-курс</label>

                                <input type="radio" class="btn-check" name="course" value="2" id="course_2">
                                <label class="btn btn-outline-primary" for="course_2">2-курс</label>
                            </div>

                            <div class="row">
                                <div class="col-md-9">
                                    <div class="form-floating mb-3">
                                        <select class="form-select" id="group"
                                                name="group" aria-label="Гуруҳни танланг" required>
                                            <option selected disabled></option>
                                            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($group->hemis_id); ?>">
                                                    <?php echo e($group->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <label for="group">Гуруҳни танланг</label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-floating mb-3">
                                        <input type="number" class="form-control" id="duration" disabled
                                               name="duration" value="80" placeholder="Дарс давомийлиги (мин.)">
                                        <label for="duration">Дарс давомийлиги (мин.)</label>
                                    </div>
                                </div>
                            </div>

                            <?php echo csrf_field(); ?>
                            <div class="form-floating mb-3">
                                <textarea class="form-control" placeholder="Дарс мавзуси (мажбурий эмас)"
                                          id="topic" name="topic" style="min-height: 100px"></textarea>
                                <label for="topic">Дарс мавзуси (мажбурий эмас)</label>
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-success w-100">
                                    Яратиш
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php if(Session::has('error')): ?>
        <div class="toast-container position-fixed bottom-0 end-0 p-3">
            <div id="liveToast" class="toast hide" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="toast-header">
                    <strong class="me-auto">Тизимда хатолик</strong>
                    <button type="button" class="btn-close" data-bs-dismiss="toast"
                            aria-label="Close"></button>
                </div>
                <div class="toast-body">
                    <?php echo Session::get('error'); ?>

                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $("input[name='course']").on('change', function () {
            let course = $(this).val();
            $.get("<?php echo e(url('/home/course')); ?>/" + course, function (data) {
                $('#group').empty().append(data);
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\zoom.lc\resources\views/meets.blade.php ENDPATH**/ ?>